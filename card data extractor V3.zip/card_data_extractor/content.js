// content.js - This script runs in the context of the web page.
// It extracts data from the page and returns it to the background script.

function extractCardData() {
    console.log("Content script running: extractCardData");
    const data = {};
    const labels = {
        "Cert #": "certNum",
        "Card Name": "cardName",
        "Game": "game",
        "Year": "year",
        "Language": "language",
        "Card Set": "cardSet",
        "Card Number": "cardNumber",
        "Variant 1": "variant1", // Assuming "Variant 1" is the label
        "Grade": "grade"
    };
    const labelKeys = Object.keys(labels);

    try {
        // Get all text content, split by lines, trim whitespace
        const text = document.body.innerText;
        const lines = text.split('\n').map(line => line.trim()).filter(line => line); // Remove empty lines

        if (lines.length === 0) {
            console.log("No text lines found in body.innerText");
            return { error: "No text content found on page." };
        }

        console.log(`Found ${lines.length} lines of text.`);

        let foundData = false;
        for (let i = 0; i < lines.length - 1; i++) {
            const currentLine = lines[i];
            if (labelKeys.includes(currentLine)) {
                const key = labels[currentLine];
                const value = lines[i + 1]; // Value is on the next line
                data[key] = value;
                foundData = true;
                console.log(`Found: ${key} = ${value}`);
            }
        }

        if (!foundData) {
             console.log("Did not find any matching labels.");
             return { error: "No matching card data labels found." };
        }

        // Specifically format the card title string required for the popup and storage
        // Ensure data.cardNumber is processed here before it's used in cardTitle
        const rawCardNumber = data.cardNumber || '';
        const cardNumberBase = rawCardNumber.split(/[\s/]/)[0];
        const variant1 = data.variant1 || '';
        const cardSet = data.cardSet || ''; // Get Card Set data

        // FIX: Corrected template literal syntax - removed unnecessary HTML spans
        const nameAndVariantPart = (data.cardName && variant1)
                                  ? `${data.cardName}-${variant1}`
                                  : data.cardName;

        let firstEditionAppend = '';
        if (cardSet.toLowerCase().includes('1st ed.')) { // Check if '1st ed.' is in cardSet
            firstEditionAppend = ' 1st Edition'; // Append " 1st Edition" with a leading space
        }

        // Concatenate all parts, then trim and replace multiple spaces with single spaces
        data.cardInfo = `${data.year || ''} ${data.game || ''} ${cardNumberBase || ''} ${nameAndVariantPart || ''}${firstEditionAppend || ''}`.trim().replace(/\s+/g, ' ');

        console.log("Extraction complete:", data);
        return data; // Return the extracted data object
    } catch (error) {
        console.error("Error in extractCardData:", error);
        return { error: `Error processing page content: ${error.message}` };
    }
}

// Call the function directly and ensure its return value is the script's result.
// This is the correct way for chrome.scripting.executeScript with 'files' to receive a result.
extractCardData();