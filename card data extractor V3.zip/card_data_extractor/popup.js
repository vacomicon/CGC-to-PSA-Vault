// popup.js
const copyButton = document.getElementById('copyButton');
const statusDiv = document.getElementById('status');
const enableCostSettingCheckbox = document.getElementById('enableCostSetting');
const manualCostInput = document.getElementById('manualCost');
const currentCostDisplay = document.getElementById('currentCostDisplay');

// Function to update the displayed current cost
async function updateCurrentCostDisplay() {
    const result = await chrome.storage.local.get(['useManualCost', 'manualCost']);
    const useManualCost = result.useManualCost === true; // Default to false
    const storedCost = result.manualCost !== undefined ? result.manualCost : 15; // Default to 15 if not set

    enableCostSettingCheckbox.checked = useManualCost;
    manualCostInput.value = storedCost;
    manualCostInput.disabled = !useManualCost; // Disable if checkbox is not checked
    currentCostDisplay.textContent = `Currently $${storedCost}`;
}

// Load settings when popup opens
document.addEventListener('DOMContentLoaded', updateCurrentCostDisplay);

// Listener for the checkbox
enableCostSettingCheckbox.addEventListener('change', async () => {
    const isChecked = enableCostSettingCheckbox.checked;
    manualCostInput.disabled = !isChecked; // Enable/disable input based on checkbox
    await chrome.storage.local.set({ 'useManualCost': isChecked });
    // If enabling, immediately update display to reflect current input value (or default)
    if (isChecked) {
        await chrome.storage.local.set({ 'manualCost': parseInt(manualCostInput.value, 10) || 15 });
        updateCurrentCostDisplay();
    }
    console.log("Use manual cost setting changed to:", isChecked);
});

// Listener for the manual cost input
manualCostInput.addEventListener('input', async () => {
    let cost = parseInt(manualCostInput.value, 10);
    if (isNaN(cost) || cost < 0) {
        cost = 0; // Prevent negative or non-numeric values
        manualCostInput.value = 0; // Correct the input field visually
    }
    await chrome.storage.local.set({ 'manualCost': cost });
    currentCostDisplay.textContent = `Currently $${cost}`;
    console.log("Manual cost updated to:", cost);
});


copyButton.addEventListener('click', async () => {
  statusDiv.textContent = 'Extracting...';
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // Check if the tab is valid for injection
  if (!tab || !tab.id || tab.url?.startsWith('chrome://')) {
      statusDiv.textContent = 'Cannot run on this page.';
      console.error('Invalid tab for injection:', tab);
      if (tab?.url?.startsWith('chrome://')) {
          statusDiv.textContent = 'Cannot access Chrome pages.';
      } else if (!tab?.id) {
          statusDiv.textContent = 'Cannot identify active tab.';
      }
      return;
  }

  try {
    // Inject the content script to extract data
    const injectionResults = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });

    // Check if injection was successful and returned results
    if (!injectionResults || injectionResults.length === 0 || !injectionResults[0].result) {
        statusDiv.textContent = 'Failed to extract data.';
        console.error('Injection failed or returned no result:', injectionResults);
        if (injectionResults && injectionResults.length > 0 && injectionResults[0].error) {
             statusDiv.textContent = `Extraction Error: ${injectionResults[0].error}`;
        }
        return;
    }

    const extractedData = injectionResults[0].result;

    if (extractedData && extractedData.error) {
        statusDiv.textContent = extractedData.error;
        console.error("Error from content script:", extractedData.error);
    } else if (extractedData && (extractedData.cardName || extractedData.certNum)) {
        // Use the pre-formatted cardInfo from content.js directly
        const titleToCopy = extractedData.cardInfo || '';

        // Write to clipboard (only if title is non-empty)
        if (titleToCopy) {
            await navigator.clipboard.writeText(titleToCopy);
            console.log('Copied:', titleToCopy);
        } else {
             console.log('Title string is empty, not copying to clipboard.');
        }

        // Store data for context menu (Cert#, Info, and Grade)
        const certNumToStore = extractedData.certNum || '';
        const gradeToStore = extractedData.grade || '';

        await chrome.storage.local.set({
            'certNum': certNumToStore,
            'cardInfo': titleToCopy, // Save the pre-formatted title
            'grade': gradeToStore
        });

        statusDiv.textContent = 'Data saved! Title copied (if found).';
        console.log('Saved Cert#:', certNumToStore);
        console.log('Saved Grade:', gradeToStore);
        console.log('Saved cardInfo:', titleToCopy);

    } else {
        statusDiv.textContent = 'Could not find card data.';
        console.log('Data extraction yielded no usable result:', extractedData);
    }

  } catch (error) {
    statusDiv.textContent = 'Error occurred.';
    console.error('Error during script execution or processing:', error);
     if (error.message.includes("Cannot access contents of url") || error.message.includes("Cannot access a chrome:// URL")) {
        statusDiv.textContent = 'Cannot run on this page (URL restriction).';
     } else if (error.message.includes("No frame with id")) {
        statusDiv.textContent = 'Cannot access this frame.';
     } else if (error.message.includes("An unexpected error occurred")) {
         statusDiv.textContent = 'Unexpected Chrome error occurred.';
     }
      else {
        statusDiv.textContent = `Error: ${error.message.substring(0, 50)}...`;
     }
  }
});