// background.js - Stable Version (May 25, 2025) - Corrected Cost Logic
// Features:
// - Context Menus:
//   1. Copy Card Info from CGC Site (page context)
//   2. Insert Card Name (editable context) - Uses processed card number & appends variant1 if present
//   3. Insert Cert # (editable context)
//   4. Fill CGC Details (editable context)
// - Separated actions for pasting Cert# vs filling Company/Grade/Cost.
// - Requires corresponding popup.js that saves 'grade'.
// - Requires content.js that extracts data, INCLUDING a field named 'variant1' for the append feature.
// - NEW: Supports sticky custom cost for "Fill CGC Details" via popup.js and chrome.storage.

// --- Context Menu Setup ---
chrome.runtime.onInstalled.addListener(() => {
  // Remove existing menus first
  chrome.contextMenus.removeAll(() => {
    console.log("Removed existing context menus.");
    // Create the new set of context menus IN THE DESIRED DISPLAY ORDER for 'editable' context

    // 1. Insert Card Name (Formerly Insert Card Info) - Appears First in editable context
    chrome.contextMenus.create({
      id: "insertCardInfo",           // Keep original ID for the logic in onClicked
      title: "Insert Card Name",        // *** CHANGED TITLE ***
      contexts: ["editable"]
    });

    // 2. Insert Cert # - Appears Second in editable context
    chrome.contextMenus.create({
      id: "insertCert",
      title: "Insert Cert #",
      contexts: ["editable"]
    });

    // 3. Fill CGC Details - Appears Third in editable context
    chrome.contextMenus.create({
      id: "fillCgcDetails",
      title: "Fill CGC Details",
      contexts: ["editable"]
    });

    // 4. Copy Card Info (Page context - its order doesn't affect the 'editable' list)
    //    We still need to create it.
    chrome.contextMenus.create({
      id: "copyCgcInfo",
      title: "Copy Card Info from CGC Site",
      contexts: ["page"]
    });

    console.log("Created context menus with updated order and title ('Insert Card Name' first).");
  });
}); // --- End of onInstalled Listener ---


// --- Context Menu Click Handler ---
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  // Log when the listener is triggered, BEFORE any checks
  console.log(`>>> onClicked triggered. Item ID: ${info.menuItemId}, Tab ID: ${tab?.id}, Frame ID: ${info?.frameId}`);

  // Revised check: Ensure tab and tab.id exist, and frameId is a non-negative integer.
  if (!tab || !tab.id || typeof info.frameId !== 'number' || info.frameId < 0) {
    console.error("<<< onClicked ERROR: Context menu clicked, but no valid tab.id or non-negative info.frameId.");
    console.error("Tab ID:", tab?.id); // Log specifics
    console.error("Frame ID:", info?.frameId); // Log specifics
    return; // Stop execution if essential info is missing
  }

  // If the check passes, continue to the switch statement...
  console.log(">>> Tab and Frame ID check passed. Proceeding to switch statement.");

  // Use a switch statement for clarity with multiple menu items
  switch (info.menuItemId) {

    // --- Action for "Copy Card Info from CGC Site" ---
    case "copyCgcInfo":
      await handleCopyCgcInfo(tab, info.frameId);
      break; // End case "copyCgcInfo"


    // --- Action for "Insert Card Name" (was "Insert Card Info") ---
    case "insertCardInfo": // ID stayed same, title changed in onInstalled
      await handleInsertCardInfo(tab, info.frameId);
      break; // End case "insertCardInfo"


    // --- Action for "Insert Cert #" (Paste Cert# ONLY) ---
    case "insertCert":
      await handleInsertCert(tab, info.frameId);
      break; // End case "insertCert"


    // --- Action for "Fill CGC Details" (Filling ONLY) ---
    case "fillCgcDetails": // New ID for this action
      await handleFillCgcDetails(tab, info.frameId);
      break; // End case "fillCgcDetails"

    // Default case if menu item ID doesn't match
    default:
      console.warn(`<<< onClicked WARNING: Unknown context menu item ID received: ${info.menuItemId}`);
  }
}); // End of contextMenus.onClicked listener


// --- Hotkey Listener ---
chrome.commands.onCommand.addListener(async (command) => {
  console.log(`Command received: ${command}`);

  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab || !tab.id || tab.url?.startsWith('chrome://')) {
      console.error('Cannot run hotkey on this page or tab is invalid:', tab);
      return;
  }

  const frameId = 0; // Assuming the main frame for hotkey actions

  switch (command) {
    case "copyCgcInfo_hotkey":
      await handleCopyCgcInfo(tab, frameId);
      break;
    case "insertCardName_hotkey":
      await handleInsertCardInfo(tab, frameId);
      break;
    case "insertCertAndFillDetails_hotkey": // Handle combined hotkey
      await handleInsertCert(tab, frameId); // First, insert cert
      await handleFillCgcDetails(tab, frameId); // Then, fill other details
      break;
    default:
      console.warn(`Unknown command: ${command}`);
  }
});


// --- Refactored Handlers for Reusability (Context Menu & Hotkey) ---

async function handleCopyCgcInfo(tab, frameId) {
  console.log(">>> handleCopyCgcInfo - Starting execution.");
  try {
    // 1. Inject content script
    console.log("handleCopyCgcInfo: Attempting to inject content.js...");
    // The content.js script now returns the pre-formatted cardInfo, including variant processing.
    const injectionResults = await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [frameId] }, files: ['content.js'] });
    console.log("handleCopyCgcInfo: content.js injection results:", injectionResults);

    if (!injectionResults || injectionResults.length === 0 || !injectionResults[0].result) {
        console.error('handleCopyCgcInfo: Injection failed or returned no result.');
        injectAlert(tab.id, frameId, 'Failed to inject script to read card data.');
        console.log("<<< handleCopyCgcInfo - Exiting due to failed injection.");
        return;
    }
    const extractedData = injectionResults[0].result;
    console.log("handleCopyCgcInfo: Extracted data:", extractedData);

    if (extractedData && extractedData.error) {
        console.error("handleCopyCgcInfo: Error from content script:", extractedData.error);
        injectAlert(tab.id, frameId, `Error reading card data: ${extractedData.error}`);
        console.log("<<< handleCopyCgcInfo - Exiting due to content script error.");
        return;
    }

    if (extractedData && (extractedData.cardInfo || extractedData.certNum)) { // Check for cardInfo directly now
      const titleToCopy = extractedData.cardInfo || ''; // Use the pre-formatted cardInfo from content.js

      // 3. Write to clipboard (via injection)
      if (titleToCopy) {
        console.log("handleCopyCgcInfo: Attempting clipboard write injection...");
        try {
            await chrome.scripting.executeScript({
                target: { tabId: tab.id, frameIds: [frameId] },
                func: (text) => {
                    navigator.clipboard.writeText(text)
                       .then(() => console.log(">>> Injected Script: Clipboard write successful."))
                       .catch((err) => console.error(">>> Injected Script: Clipboard write failed:", err));
                },
                args: [titleToCopy]
            });
            console.log('handleCopyCgcInfo: Injected clipboard write script.');
        } catch(clipError) {
            console.error("handleCopyCgcInfo: Error injecting clipboard write script:", clipError);
            injectAlert(tab.id, frameId, 'Failed to copy title to clipboard.');
        }
      } else {
          console.log("handleCopyCgcInfo: Title is empty, skipping clipboard write.");
      }

      // 4. Save data to storage (including grade!)
      const gradeToStore = extractedData.grade || '';
      console.log("handleCopyCgcInfo: Attempting to save to storage:", { certNum: extractedData.certNum, grade: gradeToStore, cardInfo: titleToCopy });
      await chrome.storage.local.set({
        'certNum': extractedData.certNum || '',
        'cardInfo': titleToCopy, // Save the pre-formatted title
        'grade': gradeToStore
      });
      console.log('handleCopyCgcInfo: Data saved to storage.');

      // 5. Inject notification
      injectNotification(tab.id, frameId, 'Card Info Copied & Saved!');

    } else {
      console.warn('handleCopyCgcInfo: Could not find usable card data on the page.');
      injectAlert(tab.id, frameId, 'Could not find recognizable card data on this page.');
    }
  } catch (error) {
    console.error("<<< handleCopyCgcInfo - Caught error during execution:", error);
    injectAlert(tab.id, frameId, `An error occurred: ${error.message}`);
  }
  console.log("<<< handleCopyCgcInfo - Execution finished.");
}

async function handleInsertCardInfo(tab, frameId) {
  console.log(">>> handleInsertCardInfo - Starting execution.");
  let cardInfoToPaste = '';
  try {
      console.log("handleInsertCardInfo: Attempting to get cardInfo from storage...");
      const result = await chrome.storage.local.get('cardInfo');
      cardInfoToPaste = result.cardInfo || '';
       console.log("handleInsertCardInfo: Retrieved cardInfo:", cardInfoToPaste);
  } catch (error) {
       console.error("handleInsertCardInfo: Error retrieving cardInfo:", error);
       injectAlert(tab.id, frameId, `Error retrieving Card Name: ${error.message}`);
       console.log("<<< handleInsertCardInfo - Exiting due to storage error.");
       return;
  }

  if (!cardInfoToPaste) {
       console.log("handleInsertCardInfo: No Card Name found in storage.");
       injectAlert(tab.id, frameId, 'No Card Name saved. Use "Copy Card Info" first.');
       console.log("<<< handleInsertCardInfo - Exiting due to no data.");
       return;
  }

   console.log("handleInsertCardInfo: Attempting to inject pasteTextOnly...");
  try {
      await chrome.scripting.executeScript({
          target: { tabId: tab.id, frameIds: [frameId] },
          func: pasteTextOnly,
          args: [cardInfoToPaste]
      });
      console.log(`handleInsertCardInfo: Injected paste script for Card Name "${cardInfoToPaste}"`);
  } catch (error) {
       console.error(`handleInsertCardInfo: Error injecting paste script:`, error);
       injectAlert(tab.id, frameId, `Error pasting Card Name: ${error.message}`);
  }
   console.log("<<< handleInsertCardInfo - Execution finished.");
}

async function handleInsertCert(tab, frameId) {
  console.log(">>> handleInsertCert - Starting execution.");
  let certNumToPaste = '';
  try {
    console.log("handleInsertCert: Attempting to get certNum from storage...");
    const result = await chrome.storage.local.get('certNum');
    certNumToPaste = result.certNum || '';
    console.log("handleInsertCert: Retrieved certNum:", certNumToPaste);
  } catch (error) {
    console.error("handleInsertCert: Error retrieving certNum:", error);
    injectAlert(tab.id, frameId, `Error retrieving Cert #: ${error.message}`);
     console.log("<<< handleInsertCert - Exiting due to storage error.");
    return;
  }

  if (!certNumToPaste) {
    console.log("handleInsertCert: No Cert # found in storage for pasting.");
    injectAlert(tab.id, frameId, 'No Cert # saved. Use "Copy Card Info" first.');
     console.log("<<< handleInsertCert - Exiting due to no data.");
    return;
  }

  console.log("handleInsertCert: Attempting to inject pasteTextOnly...");
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, frameIds: [frameId] },
      func: pasteTextOnly,
      args: [certNumToPaste]
    });
    console.log(`handleInsertCert: Injected paste script for Cert # "${certNumToPaste}"`);
  } catch (error) {
    console.error(`handleInsertCert: Error injecting paste script:`, error);
    injectAlert(tab.id, frameId, `Error pasting Cert #: ${error.message}`);
  }
   console.log("<<< handleInsertCert - Execution finished.");
}

async function handleFillCgcDetails(tab, frameId) {
  console.log(">>> handleFillCgcDetails - Starting execution.");
  let gradeToFill = '';
  let costToFill = ''; // Initialize as empty string

  try {
    console.log("handleFillCgcDetails: Attempting to get grade and cost settings from storage...");
    const result = await chrome.storage.local.get(['grade', 'useManualCost', 'manualCost']);
    gradeToFill = result.grade || '';
    const useManualCost = result.useManualCost === true; // Default to false
    const storedCost = result.manualCost !== undefined ? result.manualCost : 15; // Default to 15 if not set

    if (useManualCost) {
        costToFill = String(storedCost); // Use the stored sticky cost if enabled
        console.log("handleFillCgcDetails: Using manual cost from storage:", costToFill);
    } else {
        // If useManualCost is false, costToFill remains an empty string,
        // which will effectively clear the field or leave it empty.
        console.log("handleFillCgcDetails: Manual cost not enabled, 'my cost' field will be cleared/left empty.");
    }

    console.log("handleFillCgcDetails: Retrieved grade for filling:", gradeToFill);
  } catch (error) {
    console.error("handleFillCgcDetails: Error retrieving grade or cost settings:", error);
    injectAlert(tab.id, frameId, `Error retrieving Grade/Cost: ${error.message}`);
  }

  console.log("handleFillCgcDetails: Attempting to inject performFilling...");
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, frameIds: [frameId] },
      func: performFilling,
      args: [gradeToFill, costToFill] // Pass the dynamically determined costToFill
    });
    console.log(`handleFillCgcDetails: Injected performFilling script.`);
  } catch (error) {
    console.error(`handleFillCgcDetails: Error injecting fill script:`, error);
    injectAlert(tab.id, frameId, `Error trying to fill fields: ${error.message}`);
  }
   console.log("<<< handleFillCgcDetails - Execution finished.");
}


// --- Helper Functions ---

// Helper to inject alerts (avoids repeating try-catch)
async function injectAlert(tabId, frameId, message) {
    try {
        await chrome.scripting.executeScript({
            target: { tabId: tabId, frameIds: [frameId] },
            func: (msg) => alert(msg),
            args: [message]
        });
    } catch (err) {
        // Log error to service worker console if alert injection fails
        console.error("Failed to inject alert:", err, "Original message:", message);
    }
}

// Helper to inject temporary notifications
async function injectNotification(tabId, frameId, message) {
     try {
        await chrome.scripting.executeScript({
           target: { tabId: tabId, frameIds: [frameId] },
           func: (msg) => {
               let el = document.getElementById('card-extractor-notification-unique-id'); // More specific ID
               if (!el) {
                   el = document.createElement('div');
                   el.id = 'card-extractor-notification-unique-id';
                   // Basic styling - make it more visible
                   Object.assign(el.style, {
                       position: 'fixed', top: '20px', right: '20px',
                       backgroundColor: 'rgba(0, 100, 0, 0.85)', // Darker green, semi-transparent
                       color: 'white', padding: '12px 18px',
                       borderRadius: '5px', zIndex: '2147483647', // Max z-index
                       fontSize: '14px', fontFamily: 'sans-serif',
                       boxShadow: '0 2px 5px rgba(0,0,0,0.3)',
                       opacity: '1',
                       transition: 'opacity 0.5s ease-out 2.5s' // Fade out after 2.5 seconds
                   });
                   // Check if body exists before appending - useful for edge cases like XML viewers
                   if (document.body) {
                       document.body.appendChild(el);
                   } else {
                       console.warn("Cannot append notification: document.body not found.");
                       return; // Stop if no body
                   }
               }
               el.textContent = msg;
               el.style.opacity = '1'; // Make sure it's visible if reused

               // Clear previous timeouts if they exist
               if (el.fadeTimeout) clearTimeout(el.fadeTimeout);
               if (el.removeTimeout) clearTimeout(el.removeTimeout);

               // Set new timeouts to fade and remove
               el.fadeTimeout = setTimeout(() => { el.style.opacity = '0'; }, 2500); // Start fade slightly before removal
               el.removeTimeout = setTimeout(() => { el.remove(); }, 3000); // Remove after fade
           },
           args: [message]
        });
    } catch (e) { console.warn("Could not inject notification", e); }
}


// --- Function to be Injected for Pasting Text Only ---
// Used by "Insert Card Name" and "Insert Cert #"
function pasteTextOnly(text) {
  const activeElement = document.activeElement;
  if (activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA' || activeElement.isContentEditable)) {
    try {
        const start = activeElement.selectionStart;
        const end = activeElement.selectionEnd;
        const currentValue = activeElement.value || activeElement.textContent;

        // Ensure properties needed for manipulation exist and are correct types
        if (typeof start === 'number' && typeof end === 'number' && typeof activeElement.value === 'string') {
            activeElement.value = currentValue.substring(0, start) + text + currentValue.substring(end);
            // Move cursor to the end of the inserted text, checking if element supports selection props
             if (typeof activeElement.selectionStart === 'number') {
                 activeElement.selectionStart = activeElement.selectionEnd = start + text.length;
             }
        } else if (activeElement.isContentEditable) {
             // Use execCommand for broader compatibility in contentEditable, though deprecated, often works
             // Consider switching to Selection API or input events if issues arise
             document.execCommand("insertText", false, text);
        } else if (typeof activeElement.value === 'string'){
             // Fallback for elements that might just have a .value property (less common for right-click targets)
            activeElement.value += text;
        } else {
             console.warn(">>> Injected Script: Cannot determine how to paste into active element:", activeElement);
             return; // Don't dispatch event if paste likely failed
        }
        // Trigger an input event - essential for frameworks like React/Vue/Angular
        activeElement.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
        console.log(`>>> Injected Script: Pasted: ${text}`);
    } catch (e) {
         console.error(">>> Injected Script: Error during pasteTextOnly:", e);
    }
  } else {
    console.warn(">>> Injected Script: Paste target is not an editable element:", activeElement);
    // Avoid alerting as it can be disruptive
  }
}


// --- Function to be Injected for Filling Details ("Fill CGC Details") ---
// Contains ONLY the logic for Company, Grade, Cost
function performFilling(grade, cost) {
    // --- Start of Inner Helper Functions (needed within injection scope) ---
    function triggerEvents(element) {
        if (!element) return;
        try {
            // Trigger events in a sequence that often works for frameworks
            element.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
            element.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
            element.dispatchEvent(new Event('blur', { bubbles: true, cancelable: true })); // Triggering blur can sometimes finalize changes
        } catch (e) {
             console.warn(">>> Injected Script: Could not dispatch events on element:", element, e);
        }
    }

    function findElementByLabelText(labelText, elementType = 'input, select, textarea') {
        const normalizedLabel = labelText.trim().toLowerCase();
        let foundElement = null;
         console.log(`>>> Injected Script: Searching for element labeled "${labelText}" (type: ${elementType})`);

        // 1. Try direct label.for (most reliable if HTML is semantic)
        try {
            const labels = Array.from(document.querySelectorAll(`label`));
            // Find label that *exactly* matches or contains the text (more flexible)
            const targetLabel = labels.find(l => l.textContent.trim().toLowerCase() === normalizedLabel || l.textContent.trim().toLowerCase().includes(normalizedLabel));
            if (targetLabel && targetLabel.htmlFor) {
                const elementById = document.getElementById(targetLabel.htmlFor);
                // Check if element exists and matches the desired type
                if (elementById && elementById.matches(elementType)) {
                    console.log(`>>> Injected Script: Found element for "${labelText}" via label.for (#${targetLabel.htmlFor})`);
                    return elementById;
                }
            }
        } catch (e) { console.warn(`>>> Injected Script: Error finding "${labelText}" via label.for:`, e); }

        // 2. Try finding label and then searching nearby (handles less structured HTML)
        try {
             // Look for elements that commonly contain label text
             const potentialLabelElements = Array.from(document.querySelectorAll('label, div, span, p, td, th, dt'));
             const labelElement = potentialLabelElements.find(el => el.textContent.trim().toLowerCase() === normalizedLabel || el.textContent.trim().toLowerCase().includes(normalizedLabel));

             if (labelElement) {
                 console.log(`>>> Injected Script: Found potential label text "${labelText}" in element:`, labelElement);
                  // Search siblings of label, parent, grandparent for the control
                  let searchContext = labelElement;
                  for (let i = 0; i < 3 && searchContext; i++) { // Search up to 3 levels up from label element
                       // Check direct children first (e.g., <label><span>Label Text</span><input>...</input></label>)
                       let directChild = searchContext.querySelector(elementType);
                       if (directChild && directChild.matches(elementType)) {
                           console.log(`>>> Injected Script: Found element for "${labelText}" as descendant of label context`);
                           return directChild;
                       }

                       // Check following siblings (e.g., <label/> <input/> or <label/> <div><input>...</input></div>)
                       let sibling = searchContext.nextElementSibling;
                       while (sibling) {
                           // Check if sibling itself is the target or contains the target
                           const target = sibling.matches(elementType) ? sibling : sibling.querySelector(elementType);
                           if (target) {
                               console.log(`>>> Injected Script: Found element for "${labelText}" as sibling/descendant of label context`);
                               return target;
                           }
                           sibling = sibling.nextElementSibling;
                       }
                       // Move up the DOM tree to check parent's siblings etc.
                       searchContext = searchContext.parentElement;
                  }
             }
        } catch (e) { console.warn(`>>> Injected Script: Error finding "${labelText}" via proximity search:`, e); }


        // 3. Fallback: Try finding by common attributes (name, id, placeholder, aria-label)
        try {
             // Use more specific attribute selectors, check variations
             const selectors = [
                 `${elementType}[aria-label*="${labelText}" i]`, // Check aria-label first
                 `${elementType}[placeholder*="${labelText}" i]`,
                 `${elementType}[name="${labelText}"]`, // Exact name match
                 `${elementType}[id="${labelText}"]`,   // Exact id match
                 `${elementType}[name*="${labelText.replace(/\s+/g, '')}" i]`, // Name contains spaceless label
                 `${elementType}[id*="${labelText.replace(/\s+/g, '')}" i]`,   // ID contains spaceless label
                 `${elementType}[name*="${labelText.split(' ')[0]}" i]`, // Name contains first word
                 `${elementType}[id*="${labelText.split(' ')[0]}" i]`    // ID contains first word
             ];
             for (const selector of selectors) {
                 try { // Wrap querySelector in try-catch in case selector is invalid
                      foundElement = document.querySelector(selector);
                      if (foundElement) {
                          console.log(`>>> Injected Script: Found element for "${labelText}" via attribute selector: ${selector}`);
                          return foundElement;
                      }
                 } catch (selErr) { console.warn(`Invalid selector "${selector}": ${selErr.message}`); }
             }
        } catch (e) { console.warn(`>>> Injected Script: Error finding "${labelText}" via attribute selectors:`, e); }

        console.warn(`>>> Injected Script: Could not find element for label: "${labelText}" using type "${elementType}"`);
        return null; // Explicitly return null if nothing is found
    }

    function setSelectOptionByText(selectElement, targetText) {
         if (!selectElement || selectElement.tagName !== 'SELECT') {
             console.warn(">>> Injected Script: Invalid element passed to setSelectOptionByText:", selectElement);
             return false;
         }
         const options = Array.from(selectElement.options);
         const normalizedTargetText = targetText.trim();
         // Try exact match first
         let targetOption = options.find(option => option.text.trim() === normalizedTargetText);
         // If no exact match, try case-insensitive comparison as a fallback
         if (!targetOption) {
             targetOption = options.find(option => option.text.trim().toLowerCase() === normalizedTargetText.toLowerCase());
             if(targetOption) console.log(`Found option for "${targetText}" via case-insensitive match.`);
         }

         if (targetOption) {
             if (selectElement.value !== targetOption.value) {
                 selectElement.value = targetOption.value;
                 triggerEvents(selectElement); // Trigger events AFTER changing
                 console.log(`>>> Injected Script: Set dropdown "${selectElement.name || selectElement.id}" value to "${targetOption.value}" based on text "${targetText}"`);
                 return true;
             }
              console.log(`>>> Injected Script: Dropdown "${selectElement.name || selectElement.id}" already had correct value for "${targetText}"`);
             return true; // Already correct value
         } else {
             console.warn(`>>> Injected Script: Option with text "${normalizedTargetText}" not found in dropdown "${selectElement.name || selectElement.id}". Available options:`, options.map(o=>`'${o.text.trim()}'`).join(', '));
             return false;
         }
     }
     // --- End of Inner Helper Functions ---

    // --- Main Filling Actions ---
    let actionsTaken = [];
    console.log(">>> Injected Script: performFilling running with:", { grade, cost });

    // Action 1: Set Grading Company
    const companySelect = findElementByLabelText("Grading Company", 'select');
    if (companySelect) {
      if(setSelectOptionByText(companySelect, "CGC")) { actionsTaken.push("Grading Company set to CGC."); }
      else { actionsTaken.push("Failed to set Grading Company (Option 'CGC' not found?)."); }
    } else { actionsTaken.push("Failed to find Grading Company dropdown."); }

    // Action 2: Set Grade
    if (grade && grade.trim() !== '') {
      const gradeSelect = findElementByLabelText("Select Grade", 'select') || findElementByLabelText("Grade", 'select');
      if (gradeSelect) {
        const gradeTextToFind = `CGC ${grade.trim()}`;
        if(setSelectOptionByText(gradeSelect, gradeTextToFind)) { actionsTaken.push(`Grade selected: ${gradeTextToFind}.`); }
        else { actionsTaken.push(`Failed to select Grade (Option '${gradeTextToFind}' not found?).`); }
      } else {
        actionsTaken.push("Failed to find Grade dropdown.");
      }
    } else {
      console.log(">>> Injected Script: No grade information available to select.");
      actionsTaken.push("No grade data available to select.");
    }

    // Action 3: Set "my cost"
     // Improved search for 'my cost', potentially within 'Optional Information'
     let costInput = findElementByLabelText("my cost", 'input');
     if (!costInput) {
         console.log(">>> Injected Script: Trying to find 'my cost' within 'Optional Information' section...");
         // Look for common sectioning elements
         const optionalInfoSection = Array.from(document.querySelectorAll('div, fieldset, section, details'))
             .find(el => el.textContent.includes("Optional Information")); // Check if text content includes the phrase
         if (optionalInfoSection) {
             console.log(">>> Injected Script: Found potential 'Optional Information' section:", optionalInfoSection);
             // Search only within this section using the same label finder logic
             // Use querySelector on the found section element
              costInput = optionalInfoSection.querySelector('input[id*="cost" i], input[name*="cost" i], input[aria-label*="cost" i]');
              // Also try finding label within section
              const labelInSection = Array.from(optionalInfoSection.querySelectorAll('label')).find(l => l.textContent.trim().toLowerCase() === 'my cost');
              if (!costInput && labelInSection && labelInSection.htmlFor) {
                  costInput = optionalInfoSection.querySelector(`#${labelInSection.htmlFor}`);
              }
         }
     }
     // Final fallback to broader search if still not found
     if (!costInput) {
         console.log(">>> Injected Script: 'my cost' not found in Optional section, trying broader search...");
         costInput = findElementByLabelText("Cost", 'input') || findElementByLabelText("Purchase Price", 'input');
     }


    if (costInput) {
      // Only set the value if it's different, and if 'cost' is an empty string, it will clear the field.
      if (costInput.value !== cost) {
        costInput.value = cost;
        triggerEvents(costInput); // Trigger events
        console.log(`>>> Injected Script: Set 'my cost' field to: '${cost}'`);
        actionsTaken.push(`My Cost set to '${cost}'.`);
      } else {
        console.log(`>>> Injected Script: 'my cost' field already had value: '${cost}'`);
        actionsTaken.push("My Cost already correct.");
      }
    } else {
      actionsTaken.push("Failed to find My Cost input field.");
    }

    // Summary feedback
    console.log(">>> Injected Script: performFilling summary:", actionsTaken);
    const failures = actionsTaken.filter(action => action.toLowerCase().includes('failed'));
    if (failures.length > 0) {
       console.warn(">>> Injected Script: Some actions failed during performFilling:", failures);
       // Optionally alert user about partial failure
       // alert("Some fields could not be filled automatically.");
    } else {
        console.log(">>> Injected Script: performFilling completed successfully.");
    }
} // End of performFilling function
